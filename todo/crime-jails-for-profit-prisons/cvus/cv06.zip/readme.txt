Criminal Victimization, 2006     NCJ 219413			

This zip archive contains tables in individual  .csv spreadsheets			
from Criminal Victimization, 2006, NCJ 219413. The full report including text			
and graphics in pdf format is available from: http://www.ojp.usdoj.gov/bjs/abstract/cv06.htm.			

This report is one in a series.  More recent editions			
may be available. To view a list of all in the series go to
http://www.ojp.usdoj.gov/bjs/pubalp2.htm#cvus.			


Filename			Table title
cv06t01.csv			Table  1:   Criminal victimization in continuing areas of the NCVS sample, numbers and rates, 2005 and 2006
cv06t02.csv			Table  2:   Criminal victimization, numbers and rates, 2006
cv06t03.csv			Table  3:   Violent victimization, by gender and age, 2006
cv06t04.csv			Table  4:   Property victimization, by age of head of household, 2006
cv06t05.csv			Table  5:   Violent and property victimization, by race of victim or race of head of household, 2006
cv06t06.csv			Table  6:   Victim and offender relationship, 2006
cv06t07.csv			Table  7:   Presence of weapons in violent incidents, 2006 
cv06t08.csv			Table  8:   Percent of violent and property crimes reported to the police, 2006 
cv06at01.csv			Appendix table 1:   Percent of NCVS sample in continuing and new areas, by location, 2006
cv06at02.csv			Appendix table 2:   2005 Bounding adjustment factors, by time in sample
cv06at03.csv			Appendix table 3:   Criminal victimization rates, by type of crime and sample area, 2005 and 2006
cv06at04.csv			Appendix table 4:   Criminal victimization rates, by pre-and post-CAPI implementation, 2006

Highlights tables			
cv06h01.csv			Highlight table  1:   Crime victimization rates in urban and suburban areas remained stable between 2005 and 2006

Figures
cv06f01.csv			Figure   1:   Rates of violent victimization pre- and-post methodological redesigns
cv06f02.csv			Figure   2:   Rates of property victimization pre- and-post methodological redesigns
cv06af03.csv			Figure   3:   Rates of personal victimization, by time in sample, 2003
