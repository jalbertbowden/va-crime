Deaths in Custody Statistical Tables -
State and Local Law Enforcement Arrest-Related Deaths in the United States, 2003-2006
 
This zip archive contains tables in individual .csv spreadsheets
from Deaths in Custody Statistical Tables -State and Local Law Enforcement Arrest-Related Deaths in the United States, 2003-2006
The statistical tables are available from:
http://www.ojp.usdoj.gov/bjs/dcrp/lawenfindex.htm

		
Filename		Tables	
dcst06let1.csv	Table 1. Number of arrest-related deaths, by cause of death, 2003-2006
dcst06let2.csv	Table 2. Percent of arrest-related deaths, by cause of death, 2003-2006
dcst06let3.csv	Table 3. Number of arrest-related deaths, by selected characteristics,2003-2006
dcst06let4.csv	Table 4. Percent of arrest-related deaths, by selected characteristics, 2003-2006
dcst06let5.csv	Table 5. Number of arrest-related deaths, by selected characteristics and cause of death, 2003-2006
dcst06let6.csv	Table 6. Percent of arrest-related deaths, by selected characteristics and cause of death, 2003-2006
dcst06let7.csv	Table 7. Number of arrest-related deaths, by state, 2003-2006
dcst06let8.csv	Table 8. Number of arrest-related deaths, by state and cause of death, 2003-2006
dcst06let9.csv	Table 9. Number of arresting agencies with at least one reported arrest-related death, by state, 2003-2006
dcst06let10.csv	Table 10. Arrest-related deaths, by most serious offense, 2003-2006
dcst06let11.csv	Table 11. Percent of arrest-related deaths, by most serious offense and cause of death, 2003-2006
dcst06let12.csv	Table 12. Number of arrest-related deaths, by characteristics of the law enforcement agency involved and cause of death, 2003-2006
dcst06let13.csv	Table 13. Percent of arrest-related deaths, by characteristics of the law enforcement agency involved and cause of death, 2003-2006