Deaths in Custody Statistical Tables-Local Jail Deaths, 2000-2006
 
This zip archive contains tables in individual .csv spreadsheets
from Deaths in Custody Statistical Tables-Local Jail Deaths, 2000-2006.
The complete website including tables in .pdf format are available from:
http://www.ojp.gov/bjs/dcrp/jailsindex.htm.

		
Filename		Tables	
dcst06lj1.csv		Jail table 1. Number of local jail inmate deaths by cause of death, 2000-2006
dcst06lj2.csv		Jail table 2. Percent of local jail inmate deaths by cause of death, 2000-2006
dcst06lj3.csv		Jail table 3. Mortality rate per 100,000 local jail inmates, by cause of death, 2000-2006
dcst06lj4.csv		Jail table 4. Number of local jail inmate deaths, by selected characteristics, 2000-2006
dcst06lj5.csv		Jail table 5. Percent of local jail inmate deaths, by selected characteristics, 2000-2006
dcst06lj6.csv		Jail table 6. Mortality rate per 100,000 local jail inmates by selected characteristics, 2000-2006
dcst06lj7.csv		Jail table 7. Number of local jail inmate deaths, by 50 largest jail jurisdictions, 2000-2006
dcst06lj8.csv		Jail table 8. Mortality rate per 100,000 local jail inmates, by 50 largest jail jurisdictions, 				      2000-2006
dcst06lj9.csv		Jail table 9. Number of local jail inmate deaths, by cause of death and selected characteristics, 				      2000-2006
dcst06lj10.csv		Jail table 10. Percent of local jail inmate deaths, by cause of death and selected characteristics, 				       2000-2006
dcst06lj11.csv		Jail table 11. Average annual mortality rate per 100,000 local jail inmates, by cause of death and 				       selected characteristics, 2000-2006