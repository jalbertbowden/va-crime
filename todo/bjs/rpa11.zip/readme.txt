Requests for Police Assistance, 2011	
		
This zip archive contains tables in individual  .csv spreadsheets               		
from Requests for Police Assistance, 2011 NCJ 242938		
The full report including text and graphics in pdf format is available at:              		
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4735	
		
		
rpa11f01.csv		Figure 1. Perceptions of police behavior and response following requests for assistance, 2011
	
rpa11t01.csv		Table 1. U.S. residents age 16 or older who had contact with police, by reason for contact, 2011
rpa11t02.csv		Table 2. U.S. residents age 16 or older who requested assistance from police, by reason for contact and demographic characteristics, 2011
rpa11t03.csv		Table 3. Persons who requested police assistance who had face-to-face contact with an officer, by reason for most recent contact, 2011
rpa11t04.csv		Table 4. Perceptions of police behavior and response during contacts to request assistance, by reason for most recent contact and race/Hispanic origin of persons, 2011
rpa11t05.csv		Table 5. Perceptions of police behavior and response during contacts to request assistance, by sex and age of person, 2011
rpa11t06.csv		Table 6. Persons who felt police improved the situation during contacts to request assistance, by reason for most recent contact, 2011
rpa11t07.csv		Table 7. Persons who felt police spent an appropriate amount of time with them after requesting assistance, by perceptions of police behavior and response, 2011
rpa11t08.csv		Table 8. Persons who requested police assistance who reported how likely they were to contact police again for a similar problem, by reason for most recent contact, 2011
rpa11t09.csv		Table 9. Persons who requested police assistance who reported how likely they were to contact police again for a similar problem, by perceptions of police behavior and response, 2011
		
rpa11at01.csv		Appendix table 1. Standard errors for table 1: U.S. residents age 16 or older who had contact with police, by reason for contact, 2011
rpa11at02.csv		Appendix table 2. Standard errors for table 2: U.S. residents age 16 or older who requested assistance from police, by reason for contact and demographic characteristics, 2011
rpa11at03.csv		Appendix table 3. Standard errors for table 3: Persons who requested police assistance who had face-to-face contact with an officer, by reason for most recent contact, 2011
rpa11at04.csv		Appendix table 4. Standard errors for table 4: Perceptions of police behavior and response during contacts to request assistance, by reason for mosr recent contact and race/Hispanic origin of persons, 2011
rpa11at05.csv		Appendix table 5. Standard errors for table 5: Perceptions of police behavior and response during contacts to request assistance, by sex and age of person, 2011
rpa11at06.csv		Appendix table 6. Standard errors for table 6: Persons who felt police improved the situation during contacts to request assistance, by reason for most recent contact, 2011
rpa11at07.csv		Appendix table 7. Standard errors for table 7: Persons who felt police spent an appropriate amount of time with them after requesting assistance, by perceptions of police behavior and response, 2011
rpa11at08.csv		Appendix table 8. Standard errors for table 8: Persons who requested police assistance who reported how likely they were to contact police again for a similar problem, by reason for most recent contact, 2011
rpa11at09.csv		Appendix table 9. Standard errors for table 9: Persons who requested police assistance who reported how likely they were to contact police again for a similar problem, by perceptions of police behavior and response, 2011

