Crime Against Persons with Disabilities, 2008-2010-Statistical Tables     NCJ  235777			
			
This zip archive contains tables in individual  .csv spreadsheets			
from Crime Against Persons with Disabilities, 2008-2010-Statistical Tables,   NCJ  235777.  The full report including text			
and graphics in pdf format is available from: http://www.bjs.gov//index.cfm?ty=pbdetail&iid=2238		
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to			
http://bjs.ojp.usdoj.gov/index.cfm?ty=pbse&sid=65			
			
			
Filename			Table title
capd10t01.csv			Table 1. Violent victimizations, by type of crime and disability status, 2008-2010
capd10t02.csv			Table 2. Violent victimization rates, by type of victimization and disability status, 2008-2010
capd10t03.csv			Table 3. Violent victimization rates, by age and disability status, 2008-2010
capd10t04.csv			Table 4. Violent victimization rates, by sex, race, Hispanic origin, and disability status, 2008-2010
capd10t05.csv			Table 5. Violent victimization rates of persons with disabilities, by type of crime and type of disability, 2008-2010
capd10t06.csv			Table 6. Violent victimization rates of persons with disabilities, by type of disaiblity and sex, 2008-2010
capd10t07.csv			Table 7. Victim/offender relationship in violent crimes, by disability status, 2008-2010
capd10t08.csv			Table 8. Victim resistance in violent crimes, by disability status, 2008-2010
capd10t09.csv			Table 9. Violent crime, by offender weapon possession and disability status, 2008-2010
capd10t10.csv			Table 10. Injury and medical treatment in violent crime, by disability status, 2008-2010
capd10t11.csv			Table 11. Violent crime reported to police, by type of crime and disability status, 2008-2010
capd10t12.csv			Table 12. Violent crime in which victims used non-police victim advocacy agencies, by disability status and agency type, 2008-2010			

			
Appendix tables			
capd10at01.csv			Appendix Table 1. Standard errors for violent victimization, by type of crime and disability status, 2008-2010 
capd10at02.csv			Appendix Table 2. Standard errors for violent victimization rates, by type of victimization and disability status, 2008-2010
capd10at03.csv			Appendix Table 3. Standard errors for violent victimization rates, by age and disability status, 2008-2010
capd10at04.csv			Appendix Table 4. Standard errors for violent victimization rates, by sex, race, Hispanic origin, and disability status, 2008-2010
capd10at05.csv			Appendix Table 5. Standard errors for violent victimization rates of persons with disabilities, by type of crime and type of disability, 2008-2010
capd10at06.csv			Appendix Table 6. Standard errors for violent victimization rates of persons with disabilities, by type of disability and sex, 2008-2010
capd10at07.csv			Appendix Table 7. Standard errors for victim/offender relationship in violent crimes, by disability status, 2008-2010
capd10at08.csv			Appendix Table 8. Standard errors for victim resistance in violent crimes, by disability status, 2008-2010
capd10at09.csv			Appendix Table 9. Standard errors for violent crime, by offender weapon possession and disability status, 2008-2010
capd10at10.csv			Appendix Table 10. Standard errors for injury and medical treatment, by disability status, 2008-2010
capd10at11.csv			Appendix Table 11. Standard errors for violent crime reported to police, by type of crime and disability status, 2008-2010
capd10at12.csv			Appendix Table 12. Standard errors for violent crime in which victims used non-police victim advocacy agencies, by disability status and agency type, 2008-2010
capd10at13.csv			Appendix Table 13.  Numbers and percentages of U.S. population by disability status, sex, race, Hispanic origin, and age, 2008-2010
capd10at14.csv			Appendix Table 14.  Numbers and percentages of persons with disabilities, by type of disability, 2008-2010
capd10at15.csv			Appendix Table 15.  Violent crime against persons with disabilities, by type of interview, 2008-2010
