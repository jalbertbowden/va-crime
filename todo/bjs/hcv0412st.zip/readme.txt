"Hate Crime Victimization, 2004-2012 - Statistical Tables"		
		
This zip archive contains tables in individual  .csv spreadsheets               		
"from Hate Crime Victimization, 2004-2012 - Statistical Tables NCJ 244409"		
The full report including text and graphics in pdf format is available at:              		
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4883		
		
This report is one in a series. More recent editions may be available. 
To view a list of all in the series go to 
http://bjs.ojp.usdoj.gov/index.cfm?ty=dcdetail&iid=72		
		
hcv0412stf01.csv		Figure 1. Violent hate crime victimizations reported and not reported to police, 2004�2012
hcv0412stf02.csv		Figure 2. NCVS and UCR hate crime victimizations, 2004�2012
		
hcv0412stt01.csv		Table 1. Hate crime victimizations, 2004�2012
hcv0412stt02.csv		Table 2. Victims� perceptions of offender bias in hate crimes, 2004, 2011, and 2012
hcv0412stt03.csv		Table 3. Hate and nonhate crime victimizations, by type of crime, 2004, 2011, and 2012
hcv0412stt04.csv		Table 4. Presence of weapons and injuries sustained in violent hate and nonhate crime victimizations, 2004�2012
hcv0412stt05.csv		Table 5. Hate crime victimizations reported to police, 2004, 2011, and 2012
hcv0412stt06.csv		Table 6. Characteristics of violent hate crime victims, 2004, 2011, and 2012
hcv0412stt07.csv		Table 7. Characteristics of violent hate crime offenders as reported by victims, 2004, 2011, and 2012
hcv0412stt08.csv		Table 8. Hate crime victimizations recorded by the NCVS and UCR, 2004�2012
		
hcv0412stat01.csv		Appendix table 1. Estimates and standard errors for figure 1: Violent hate crime victimizations reported and not reported to police, 2004�2012
hcv0412stat02.csv		Appendix table 2. Population and total criminal victimization counts, 2004�2012
hcv0412stat03.csv		Appendix table 3. Standard errors for table 1: Hate crime victimizations, 2004�2012
hcv0412stat04.csv		Appendix table 4. Standard errors for table 2: Victims� perceptions of offender bias in hate crimes, 2004, 2011, and 2012
hcv0412stat05.csv		Appendix table 5. Standard errors for table 3: Hate and nonhate crime victimizations, by type of crime, 2004, 2011, and 2012
hcv0412stat06.csv		Appendix table 6. Standard errors for table 4: Presence of weapons and injuries sustained in violent hate and nonhate crime victimizations, 2004�2012
hcv0412stat07.csv		Appendix table 7. Standard errors for table 5: Hate crime victimizations reported to police, 2004, 2011, and 2012
hcv0412stat08.csv		Appendix table 8. Standard errors for table 6: Characteristics of violent hate crime victims, 2004, 2011, and 2012
hcv0412stat09.csv		Appendix table 9. Standard errors for table 7: Characteristics of violent hate crime offenders as reported by victims, 2004, 2011, and 2012
hcv0412stat10.csv		Appendix table 10. Standard errors for table 8: Hate crime victimizations recorded by the NCVS and UCR, 2004�2012
