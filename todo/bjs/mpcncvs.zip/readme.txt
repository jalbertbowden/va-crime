Measuring the Prevalence of Crime with the National Crime Victimization Survey		
		
This zip archive contains tables in individual  .csv spreadsheets               		
from Measuring the Prevalence of Crime with the National Crime Victimization Survey NCJ 241656		
The full report including text and graphics in pdf format is available at:              		
http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4759		
		
		
mpcncvsf01.csv		Figure 1. Total violent victimization rate and prevalence rate, 1993?2010
mpcncvsf02.csv		Figure 2. Serious violent victimization rate and prevalence rate, 1993?2010
mpcncvsf03.csv		Figure 3. Female rape and sexual assault victimization rate and prevalence rate, 1993?2010
mpcncvsf04.csv		Figure 4. Robbery victimization rate and prevalence rate, 1993-2010
mpcncvsf05.csv		Figure 5. Aggravated assault victimization rate and prevalence rate, 1993?2010
mpcncvsf06.csv		Figure 6. Simple assault victimization rate and prevalence rate, 1993?2010
mpcncvsf07.csv		Figure 7. Percent victimized of persons age 12 or older, by type of violent crime, 1993?2010
mpcncvsf08.csv		Figure 8. Total property victimization rate and prevalence rate, 1993?2010
mpcncvsf09.csv		Figure 9. Burglary victimization rate and prevalence rate, 1993-2010
mpcncvsf10.csv		Figure 10. Motor vehicle theft victimization rate and prevalence rate, 1993?2010
mpcncvsf11.csv		Figure 11. Theft victimization rate and prevalence rate, 1993?2010
		
mpcncvst01.csv		Table 1. Violent victimization rate, prevalence rate, and number of victimizations per victim, by type of crime, 1993 and 2010
mpcncvst02.csv		Table 2. Number of violent victimizations and victims, by type of crime, 1993 and 2010
mpcncvst03.csv		Table 3. Number and rate of violent victimization, by sex and age of victim, 2010
mpcncvst04.csv		Table 4. Violent victimization, by victim-offender relationship and sex, 2010
mpcncvst05.csv		Table 5. Violent victimization, by age and victim-offender relationship, 2010
mpcncvst06.csv		Table 6. Household property crime victimization rate, prevalence rate, and number of victimizations per household, by type of crime, 1993 and 2010
mpcncvst07.csv		Table 7. Number of property victimizations and victims, by type of crime, 1993 and 2010
		
mpcncvsat01.csv		Appendix table 1. Estimates and standard errors for figure 1: Total violent victimization rate and prevalence rate, 1993?2010
mpcncvsat02.csv		Appendix table 2. Standard errors for table 1: Violent victimization rate, prevalence rate and number of victimizations per victim, by type of crime, 1993 and 2010 
mpcncvsat03.csv		Appendix table 3. Standard errors for table 2: Number of violent victimizations and victims, by type of crime, 1993 and 2010
mpcncvsat04.csv		Appendix table 4. Estimates and standard errors for figure 2: serious violent victimization rate and prevalence rate, 1993?2010
mpcncvsat05.csv		Appendix table 5. Estimates and standard errors for figure 3: Female rape and sexual assault victimization rate and prevalence rate, 1993?2010
mpcncvsat06.csv		Appendix table 6. Estimates and standard errors for figure 4: Robbery victimization rate and prevalence rate, 1993?2010
mpcncvsat07.csv		Appendix table 7. Estimates and standard errors for figure 5: Aggravated assault victimization rate and prevalence rate, 1993?2010
mpcncvsat08.csv		Appendix table 8. Estimates and standard errors for figure 6: Simple assault victimization rate and prevalence rate, 1993?2010
mpcncvsat09.csv		Appendix table 9. Estimates and standard errors for figure 7: Percent of victimized persons age 12 or older, by type of violent crime, 1993?2010
mpcncvsat10.csv		Appendix table 10. Standard errors for table 3: Number and rate of violent victimization, by sex and age of victim, 2010
mpcncvsat11.csv		Appendix table 11. Standard errors for table 4: Violent victimization, by sex and victim-offender relationship, 2010
mpcncvsat12.csv		Appendix table 12. Standard errors for table 5: Violent victimization, by age and victim-offender relationship, 2010
mpcncvsat13.csv		Appendix table 13. Estimates and standard errors for figure 8: Total property victimization rate and prevalence rate, 1993?2010
mpcncvsat14.csv		Appendix table 14. Standard errors for table 6: Household property crime victimization rate, prevalence rate, and number of victimizations per household, by type of crime, 1993 and 2010
mpcncvsat15.csv		Appendix table 15. Estimates and standard errors for figure 9: Burglary victimization rate and prevalence rate, 1993?2010
mpcncvsat16.csv		Appendix table 16. Estimates and standard errors for figure 10: Motor vehicle theft victimization rate and prevalence rate, 1993?2010
mpcncvsat17.csv		Appendix table 17. Estimates and standard errors for figure 11: Theft victimization rate and prevalence rate, 1993?2010
mpcncvsat18.csv		Appendix table 18. Standard errors for table 7: Number of property victimizations and victims, by type of crime, 1993 and 2010
