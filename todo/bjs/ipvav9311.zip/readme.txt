Intimate Partner Victimization: Attributes of the Victimization, 1993-2011   NCJ 243300			
			
This zip archive contains tables in individual  .csv spreadsheets			
from Intimate Partner Victimization: Attributes of the Victimization, 1993-2011   NCJ 243300.  The full report including text			
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4801			
			
			
			
Filename			Table title
ipvavt01.csv			Table 1. Violent victimization, by victim�s sex and victim-offender relationship, 2002�2011
ipvavt02.csv			Table 2. Homicide, by victim�s sex and victim-offender relationship, 1993�2010
ipvavt03.csv			Table 3. Type of physical attack in violent victimization, by victim�s sex and victim-offender relationship, 2002�2011
ipvavt04.csv			Table 4. Presence of weapons, by victim's sex and victim-offender relationship, 2002�2011
ipvavt05.csv			Table 5. Physical injury, by victim�s sex and victim-offender relationship, 2002�2011
ipvavt06.csv			Table 6. Medical treatment, by victim's sex and victim-offender relationship, 2002�2011
ipvavt07.csv			Table 7. Summary attributes of violent victimization, by victim�s sex and victim-offender relationship, 2002�2011
			
Figures			
ipvavf01.csv			Figure 1. Rate of intimate partner violence, by victim�s sex, 1994�2011
ipvavf02.csv			Figure 2. Serious intimate partner violence against females, 1994�2011
ipvavf03.csv			Figure 3. Physical attacks and threats in intimate partner violence against females, 1994�2011
ipvavf04.csv			Figure 4. Presence of weapons in intimate partner violence against females, 1994�2011
ipvavf05.csv			Figure 5. Physical injury in intimate partner violence against females, 
ipvavf06.csv			Figure 6. Medical treatment of female victims of intimate partner violence, 1994-2011
			
Appendix tables			
ipvavat01.csv			Appendix table 1. Number and rate of intimate partner violence, by victim's sex, 1993�2011
ipvavat02.csv			Appendix table 2. Standard errors for appendix table 1: Number and rate of intimate partner violence, by victim's sex, 1993�2011
ipvavat03.csv			Appendix table 3. Serious intimate partner violence against females, 1993�2011
ipvavat04.csv			Appendix table 4. Standard errors for apendix table 3: Serious intimate partner violence against females, 1993-2011
ipvavat05.csv			Appendix table 5. Standard errors for table 1: Violent victimization, by victim�s sex and victim-offender relationship, 2002�2011
ipvavat06.csv			Appendix table 6. Physical attacks and threats in intimate partner violence against females, 1993�2011
ipvavat07.csv			Appendix table 7. Standard errors for appendix table 6: Physical attacks and threats in intimate partner violence against females, 1993�2011
ipvavat08.csv			Appendix table 8. Standard errors for table 3: Type of physical attack in violent victimization, by victim�s sex and victim-offender relationship, 2002�2011
ipvavat09.csv			Appendix table 9. Presence of weapons in intimate partner violence against females, 1993�2011
ipvavat10.csv			Appendix table 10. Standard errors for appendix table 9: Presence of weapons in intimate partner violence against females, 1993�2011
ipvavat11.csv			Appendix table 11. Standard errors for table 4. Presence of weapons, by victim's sex and victim-offender relationship, 2002�2011
ipvavat12.csv			Appendix table 12. Physical injury in intimate partner violence against females, 1993�2011
ipvavat13.csv			Appendix table 13. Standard errors for appendix table 12: Physical injury in intimate partner violence against females, 1993�2011
ipvavat14.csv			Appendix table 14. Standard errors for Table 5: Physical injury, by victim�s sex and victim-offender relationship, 2002�2011
ipvavat15.csv			Appendix table 15. Medical treatment of female victims of intimate partner violence, 1993�2011
ipvavat16.csv			Appendix table 16. Standard errors for appendix table 15: Medical treatment of female victims of intimate partner violence, 1993�2011
ipvavat17.csv			Appendix table 17. Standard errors for table 6: Medical treatment, by victim�s sex and victim-offender relationship, 2002�2011
