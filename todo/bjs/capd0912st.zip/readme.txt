Crime Against Persons with Disabilities, 2009-2012-Statistical Tables     NCJ 244525			
			
This zip archive contains tables in individual  .csv spreadsheets			
from Crime Against Persons with Disabilities, 2009-2012-Statistical Tables, NCJ 244525.  The full report including text			
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4884			
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to
http://www.bjs.gov/index.cfm?ty=pbse&sid=65		
			
			
			
Filename				Title
Tables
cap0912stt01.csv			Table 1. Annual number of violent crimes, by type of crime and victim's disability status, 2008-2012
cap0912stt02.csv			Table 2. Unadjusted violent victimization rates, by victim's disability status, 2009-2012
cap0912stt03.csv			Table 3. Age-adjusted and unadjusted rates of violent victimization for persons with disabilities, by type of crime, 2009-2012
cap0912stt04.csv			Table 4. Age-adjusted and unadjusted rates of violent victimization for persons without disabilities, by type of crime, 2009-2012
cap0912stt05.csv			Table 5. Age-adjusted rates of violent victimization, by victim's disability status, sex, race, and Hispanic origin, 2009-2012
cap0912stt06.csv			Table 6. Percent of violence against persons with disabilities that involved victims with multiple disability types, by type of crime, 2009-2012
cap0912stt07.csv			Table 7. Age-adjusted rates of violent victimization, by type of crime and number of disability types, 2009-2012
cap0912stt08.csv			Table 8. Unadjusted rate of violent victimization against persons with disabilities, by disability type, 2009-2012
cap0912stt09.csv			Table 9. Unadjusted rate of serious violent victimization against persons with disabilities, by disability type, 2009-2012
cap0912stt10.csv			Table 10. Unadjusted rate of simple assault against persons with disabilities, by disability type, 2009-2012
cap0912stt11.csv			Table 11. Unadjusted violent victimization rate, by victim's sex and disability type, 2009-2012

Appendix tables
cap0912stat01.csv			Appendix table 1. Standard errors for table 1: Annual number of violent crimes, by type of crime and victim's disability status, 2008-2012
cap0912stat02.csv			Appendix table 2. Standard errors for table 2: Unadjusted violent victimization rates, by victim's disability status and age, 2009-2012
cap0912stat03.csv			Appendix table 3. Standard errors for table 3: Age-adjusted and unadjusted rates of violent victimization for persons with disabilities, by type of crime, 2009-2012
cap0912stat04.csv			Appendix table 4. Standard errors for table 4: Age-adjusted and unadjusted rates of violent victimization for persons without disabilities, by type of crime, 2009-2012
cap0912stat05.csv			Appendix table 5. Standard errors for table 5: Age-adjusted rates of violent victimization, by victim's disability status, sex, race, and Hispanic origin, 2009-2012
cap0912stat06.csv			Appendix table 6. Standard errors for table 6: Percent of violence against persons with disabilities that involved victims with multiple disability types, by type of crime, 2009-2012
cap0912stat07.csv			Appendix table 7. Standard errors for table 7: Age-adjusted rates of violent victimization, by type of crime and number of disability types, 2009-2012
cap0912stat08.csv			Appendix table 8. Standard errors for table 8: Unadjusted rate of violent victimization against persons with disabilities, by disability type, 2009-2012
cap0912stat09.csv			Appendix table 9. Standard errors for table 9: Unadjusted rate of serious violent victimization against persons with disabilities, by disability type, 2009-2012
cap0912stat10.csv			Appendix table 10. Standard errors for table 10: Unadjusted rate of simple assault against persons with disabilities, by disability type, 2009-2012
cap0912stat11.csv			Appendix table 11. Standard errors for table 11: Unadjusted violent victimization rate, by victim's sex and disability type, 2009-2012
cap0912stat12.csv			Appendix table 12. Annual number and percent of U.S. population with disabilities by demographic characteristics, 2008-2012
cap0912stat13.csv			Appendix table 13. Annual number and percent of U.S. population without disabilities, by demographic characteristics, 2008-2012
cap0912stat14.csv			Appendix table 14. U.S. population according to the Census Bureau's ACS and PUMS data, by victim's disability status and demographic characteristics, 2010
cap0912stat15.csv			Appendix table 15. U.S. population calculated and according to the Census Bureau's PUMS data, by victim's disability status and demographic characteristics, 2011
cap0912stat16.csv			Appendix table 16. Unadjusted rate of violent victimization, by victim's disability status, sex, race, and Hispanic origin, 2009-2012
cap0912stat17.csv			Appendix table 17. Standard errors for appendix table 16: Unadjusted rate of violent victimization, by victim's disability status, sex, race, and Hispanic origin, 2009-2012
cap0912stat18.csv			Appendix table 18. Unadjusted rate of violent victimization against persons with disabilities, by type of crime and number of disability types, 2009-2012
cap0912stat19.csv			Appendix table 19. Standard errors for appendix table 18:  Unadjusted rate of violent victimization against persons with disabilities, by type of crime and number of disability types, 2009-2012
