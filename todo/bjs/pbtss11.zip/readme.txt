Police Behavior during Traffic and Street Stops, 2011		
		
This zip archive contains tables in individual  .csv spreadsheets               		
from Police Behavior during Traffic and Street Stops, 2011 NCJ 242937		
The full report including text and graphics in pdf format is available at:  
https://www.bjs.gov/index.cfm?ty=pbdetail&iid=4734            		
		
		
This report is one in a series. More recent editions may be available. To view a list of all in the series go to		
		
pbtss11f01.csv		Figure 1. Perceptions that police behaved properly during contact with persons 16 or older, by type of contact, 2011. 
		
pbtss11t01.csv		Table 1. Involuntary contact with police among persons age 16 or older, by demographic characteristics and type of contact, 2011 
pbtss11t02.csv		Table 2. Perception that reason for traffic stop was legitimate among drivers age 16 or older, by race or Hispanic origin of driver and reason for stop, 2011
pbtss11t03.csv		Table 3. Perception that reason for traffic stop was legitimate among drivers age 16 or older, by reason for stop and whether driver and officer were intra- or interracial, 2011
pbtss11t04.csv		Table 4. Perception that reason for traffic stop was legitimate among drivers age 16 or older, by race and ethnicity of driver and officer and driver�s perception that police behaved properly, 2011
pbtss11t05.csv		Table 5. Enforcement actions taken by police against drivers age 16 or older, by driver�s demographic characteristics and perception that police behaved properly, 2011
pbtss11t06.csv		Table 6. Stopped drivers age 16 or older who were ticketed, by race of officer and driver and driver�s perception that police behaved properly, 2011
pbtss11t07.csv		Table 7. Stopped drivers age 16 or older who were searched by police, by driver�s demographic characteristics and perception that police behaved properly, 2011
pbtss11t08.csv		Table 8. Stopped drivers age 16 or older who had their person or vehicle searched by police, by perception that police behaved properly, 2011
pbtss11t09.csv		Table 9. Type of force used or threatened by police against stopped drivers age 16 or older, by perception that police behaved properly, 2011
pbtss11t10.csv		Table 10. Reason for street stops involving persons age 16 or older, by perceptions that stop was legitimate and police behaved properly, 2011
pbtss11t11.csv		Table 11. Characteristics of persons age 16 or older involved in street stops and outcomes of the stop, by perceptions that police behaved properly, 2011
		
pbtss11a01.csv		Appendix table 1. Standard errors and estimates for figure 1: Perceptions that police behaved properly and respectfully during most recent contact with persons age 16 or older, by type of contact, 2011
pbtss11a02.csv		Appendix table 2. Population of persons age 16 or older and driving population age 16 or older, by demographic characteristics, 2011
pbtss11a03.csv		Appendix table 3. Standard errors for table 1: Involuntary contact with police among persons age 16 or older, by demographic characteristics and type of contact, 2011
pbtss11a04.csv		Appendix table 4. Standard errors for table 2: Perception that reason for traffic stop was legitimate among drivers age 16 or older, by race or Hispanic origin of driver and reason for stop, 2011
pbtss11a05.csv		Appendix table 5. Standard errors for table 3: Perception that reason for traffic stop was legitimate among drivers age 16 or older, by reason for stop and whether driver and officer were intra- or interracial, 2011
pbtss11a06.csv		Appendix table 6. Standard errors for table 4: Perception that reason for traffic stop was legitimate among drivers age 16 or older, by race and ethnicity of driver and officer and driver�s perception that police behaved properly, 2011
pbtss11a07.csv		Appendix table 7. Standard errors for table 5: Enforcement actions taken by police against drivers age 16 or older, by driver�s demographic characteristics and perception that police behaved properly, 2011
pbtss11a08.csv		Appendix table 8. Standard errors for table 6: Stopped drivers age 16 or older who were ticketed, by race of officer and driver and driver�s perception that police behaved properly, 2011
pbtss11a09.csv		Appendix table 9. Standard errors for table 7: Stopped drivers who were searched by police, by driver�s demographic characteristics and perception that police behaved properly, 2011
pbtss11a10.csv		Appendix table 10. Standard errors for table 8: Stopped drivers age 16 or older who had their person or vehicle searched by police, by driver�s perception that police behaved properly, 2011Appendix table 9. Standard errors for table 7: Stopped drivers who were searched by police, by driver�s demographic characteristics and perception that police behaved properly, 2011
pbtss11a11.csv		Appendix table 11. Standard errors for table 9: Type of force used or threatened by police against stopped drivers, by driver�s perception that police behaved properly, 2011
pbtss11a12.csv		Appendix table 12. Standard errors for table 10: Reason for street stops involving persons age 16 or older, by perceptions that stop was legitimate and police behaved properly, 2011
pbtss11a13.csv		Appendix table 13. Standard errors for table 11: Characteristics of persons age 16 or older involved in street stops and outcomes of the stop, by perceptions that police behaved properly, 2011Appendix table 12. Standard errors for table 10: Reason for street stops involving persons age 16 or older, by perceptions that stop was legitimate and police behaved properly, 2011
