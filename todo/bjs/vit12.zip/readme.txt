Victims of Identity Theft, 2012      NCJ 243779			
			
This zip archive contains tables in individual  .csv spreadsheets			
from Victims of Identity Theft, 2012, NCJ 243779.  The full report including text			
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4796			
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to
http://www.bjs.gov/index.cfm?ty=pbse&sid=60		
			
			
			
Filename			Title
Tables
vit12t01.csv			Table 1. Persons age 16 or older who experienced at least one identity theft incident in the past 12 months, by type of theft, 2012
vit12t02.csv			Table 2. Persons age 16 or older who experienced at least one identity theft incident in the past 12 months, by victim characteristics, 2012
vit12t03.csv			Table 3. Identity theft victims who knew something about the offender, by type of theft, 2012
vit12t04.csv			Table 4. Mean, median, and total losses attributed to property crime and identity theft, 2012
vit12t05.csv			Table 5. Persons age 16 or older who experienced identity theft at any point in their lives, type of identity theft they experienced outside of the past year, and ongoing problems from identity theft that occurred outside of the past year, 2012
vit12t06.csv			Table 6. Actions victims and nonvictims took during the past 12 months to reduce the risk of identity theft, by whether the action was taken in response to theft, 2012

Figures			
vit12f01.csv			Figure 1. Persons age 16 or older who experienced at least one identity theft incident in the past 12 months, by type of theft, 2012
vit12f02.csv			Figure 2. Most common ways victims discovered identity theft, by type of theft, 2012
vit12f03.csv			Figure 3. Identity theft victims who knew how their personal information was obtained, by type of theft, 2012
vit12f04.csv			Figure 4. Total out-of-pocket losses for identity theft victims experiencing a loss of $1 or more, 2012
vit12f05.csv			Figure 5. Victims who experienced financial or legal problems as a result of identity theft, by type of theft, 2012
vit12f06.csv			Figure 6. Victims of identity theft and violent crime who experienced problems as a result of the victimization, 2012
vit12f07.csv			Figure 7. Level of emotional distress reported by identity theft and violent crime victims, 2012
vit12f08.csv			Figure 8. Length of time spent resolving financial and credit problems associated with identity theft, by type of identity theft, 2012
vit12f09.csv			Figure 9. Identity theft victims who reported work/school or family/friend problems or distress, by length of time spent resolving associated financial and credit problems, 2012
vit12f10.csv			Figure 10. Identity theft victims who reported the incident to police, by type of identity theft, 2012
vit12f11.csv			Figure 11. Identity theft victims who contacted a credit bureau, by action taken, 2012
			
Appendix tables			
vit12at01.csv			Appendix table 1. Standard errors for figure 1: Persons age 16 or older who experienced at least one identity theft incident in the past 12 months, by type of theft, 2012 and table 1: Persons age 16 or older who experienced at least one identity theft incident in the past 12 months, by type of theft, 2012
vit12at02.csv			Appendix table 2. Standard errors for table 2: Persons age 16 or older who experienced at least one identity theft incident in the past 12 months, by victim characteristics, 2012
vit12at03.csv			Appendix table 3. Ways that victims discovered identity theft, by type of theft, 2012
vit12at04.csv			Appendix table 4. Estimates and standard errors for figure 3: Identity theft victims who knew how their personal information was obtained, by type of theft, 2012
vit12at05.csv			Appendix table 5. Standard errors for table 3: Identity theft victims who knew something about the offender, by type of theft, 2012
vit12at06.csv			Appendix table 6. Standard errors for table 4: Mean losses attributed to property crime and identity theft, 2012
vit12at07.csv			Appendix table 7. Estimates and standard errors for figure 4: Total out-of-pocket losses for identity theft victims experiencing a loss of $1 or more, 2012
vit12at08.csv			Appendix table 8. Financial loss among victims who experienced at least one attempted or successful identity theft incident during the previous 12 months, by type of theft and type of loss, 2012
vit12at09.csv			Appendix table 9. Standard errors for appendix table 8. Financial loss among victims who experienced at least one attempted or successful identity theft incident during the previous 12 months, by type of theft and type of loss, 2012
vit12at10.csv			Appendix table 10. Estimates and standard errors for figure 5: Victims who experienced financial or legal problems as a result of identity theft, by type of theft, 2012
vit12at11.csv			Appendix table 11. Identity theft and violent crime victims who experienced emotional distress, by type of identity theft and violent crime, 2012
vit12at12.csv			Appendix table 12. Standard errors for appendix table 11: Identity theft and violent crime victims who experienced emotional distress, by type of identity theft and violent crime, 2012
vit12at13.csv			Appendix table 13. Identity theft victims who resolved associated problems and length of time spent resolving problems, 2012
vit12at14.csv			Appendix table 14. Standard errors for appendix table 13: Identity theft victims who resolved associated problems and length of time spent resolving problems, 2012
vit12at15.csv			Appendix table 15. Standard errors for table 5: Persons age 16 or older who experienced identity theft at any point in their lives, type of identity theft they experienced outside of the past year, and ongoing problems from identity theft that occurred outside of the past year, 2012
vit12at16.csv			Appendix table 16. Estimates and standard errors for figure 9: Identity theft victims who reported work/school or family/friend problems or distress, by length of time spent resolving associated financial and credit problems, 2012
vit12at17.csv			Appendix table 17. Victims who did and did not report identity theft to police, by type of theft and reason for not reporting, 2012
vit12at18.csv			Appendix table 18. Standard errors for appendix table 17: Victims who did and did not report identity theft to police, by type of theft and reason for not reporting, 2012
vit12at19.csv			Appendix table 19. Identity theft victims who contacted an organization, by type of theft, and credit bureau action, 2012
vit12at20.csv			Appendix table 20. Standard errors for appendix table 19: Identity theft victims who contacted an organization, by type of theft, and credit bureau action, 2012
vit12at21.csv			Appendix table 21. Standard errors for table 6: Actions victims and nonvictims took during the past 12 months to reduce the risk of identity theft, by whether the action was taken in response to theft, 2012
