Criminal Victimization in the United States, 2008   NCJ# 231173 

This zip archive contains tables in individual .csv spreadsheets from the 2008 National Crime Victimization Survey.
It is one of a series of files from the National Crime Victimization Survey.
All of the files may be obtained from http://www.bjs.gov/index.cfm?ty=pbdetail&iid=2218
Five sections are archived -- demography of victims, victims and offenders, 
geography, crime event, victims and the criminal justice system, and series victimizations.
  
Text files: cvusmet.txt --detailed information about the National Crime Victimization Survey and the results from the data collection throughout 
United States (Methodology). 

Spreadsheets
 
File Name    Table Titles
 
             DEMOGRAPHY OF VICTIMS
cv0801.csv   Table 1: Number, percent distribution, and rate of victimizations, by type of crime
cv0802.csv   Table 2: Number of victimizations and victimization rates for persons age 12 and over, by type of crime and sex of victims
cv0803.csv   Table 3: Victimization rates for persons age 12 and over, by type of crime and age of victims
cv0807.csv   Table 4: Victimization rates for persons age 12 and over, by sex and age of victims and type of crime
cv0805.csv   Table 5: Number of victimizations and victimization rates for persons age 12 and over, by type of crime and race of victims
cv0806.csv   Table 6: Number of victimizations and victimization rates for persons age 12 and over, by type of crime and sex and race of victims
cv0807.csv   Table 7: Number of victimizations and victimization rates for persons age 12 and over, by type of crime and ethnicity of victims
cv0808.csv   Table 8: Victimization rates for persons age 12 and over, by type of crime and ethnicity and sex of victims
cv0809.csv   Table 9: Victimization rates for persons age 12 and over, by race and age of victims and type of crime
cv0810.csv   Table 10: Number of victimizations and victimization rates for persons age 12 and over, by race, sex, and age of victims and type of crime
cv0811.csv   Table 11: Victimization rates for persons age 12 and over, by type of crime and marital status of victims
cv0812.csv   Table 12: Victimization rates for persons age 12 and over, by sex and marital status of victims and type of crime
cv0813.csv   Table 13: Victimization rates for persons age 12 and over, by sex of head of household, relationship of victims to head and type of crime
cv0814.csv   Table 14: Victimization rates for persons age 12 and over, by type of crime and annual family income of victims
cv0815.csv   Table 15: Victimization rates for persons age 12 and over, by race and annual family income of victims and type of crime
cv0816.csv   Table 16: Number of victimizations and victimization rates by type of crime and race of head of household
cv0817.csv   Table 17: Number of victimizations and victimization rates by type of crime and ethnicity of head of household
cv0818.csv   Table 18: Number of victimizations and victimization rates on the basis of thefts per 1,000 households and of thefts per 1,000 vehicles owned, by selected household characteristics
cv0819.csv   Table 19: Victimization rates by type of crime and age of head of household
cv0820.csv   Table 20: Victimization rates by type of crime and annual family income
cv0821.csv   Table 21: Victimization rates by race of head of household, annual family income and type of household burglary
cv0822.csv   Table 22: Victimization rates by race of head of household, annual family income and type of theft
cv0823.csv   Table 23: Victimization rates by race of head of household, annual family income and type of motor vehicle theft
cv0824.csv   Table 24: Victimization rates by type of crime and number of persons in household
cv0825.csv   Table 25: Victimization rates by type of crime and number of units in structure occupied by household
 
              VICTIMS AND OFFENDERS
cv0826.csv   Table 26: Number of incidents and victimizations and ratio of victimizations to incidents, by type of crime
cv0827.csv   Table 27: Number and percent distribution of incidents, by type of crime and victim-offender relationship
cv0828.csv   Table 28: Number of victimizations and victimization rates for persons age 12 and over, by type of crime and victim-offender relationship
cv0829.csv   Table 29: Percent of victimizations involving strangers, by sex and age of victims and type of crime
cv0830.csv   Table 30: Percent of victimizations involving strangers, by sex and race of victims and type of crime
cv0831.csv   Table 31: Percent of victimizations involving strangers, by sex and marital status of victims and type of crime
cv0832.csv   Table 32: Percent distribution of victimizations, by perceived drug or alcohol use by offender
cv0833.csv   Table 33: Number of victimizations, by type of crime and relationship to offender 
cv0834.csv   Table 34: Percent distribution of victimizations, by type of crime and relationship to offender
cv0835.csv   Table 35: Victimization rate by victim-offender relationship, by type of crime and selected victim characteristics
cv0836.csv   Table 36: Percent distribution of incidents, by type of crime and number of victims
cv0837.csv   Table 37: Percent distribution of incidents, by victim-offender relationship, type of crime and number of offenders                  
cv0838.csv   Table 38: Percent distribution of single-offender victimizations, by type of crime and perceived sex of offender
cv0839.csv   Table 39: Percent distribution of single-offender victimizations, by type of crime and perceived age of offender
cv0840.csv   Table 40: Percent distribution of single-offender victimizations, by type of crime and perceived race of offender
cv0841.csv   Table 41: Percent distribution of single-offender victimizations, by type of crime, age of victims and perceived age of offender
cv0842.csv   Table 42: Percent distribution of single-offender victimizations, based on race of victims, by type of crime and perceived race of offender
cv0843.csv   Table 43: Percent distribution of single-offender victimizations, by type of crime and detailed victim-offender relationship
cv0843a.csv Table 43a: Percent distribution of victimizations, by characteristics of victims, type of crime, and victim/offender relationship
cv0844.csv   Table 44: Percent distribution of multiple-offender victimizations, by type of crime and perceived sex of offender
cv0845.csv   Table 45: Percent distribution of multiple-offender victimizations, by type of crime and perceived age of offenders
cv0846.csv   Table 46: Percent distribution of multiple-offender victimizations, by type of crime and perceived race of offenders
cv0847.csv   Table 47: Percent distribution of multiple-offender victimizations, by type of crime, age of victims and perceived age of offenders
cv0848.csv   Table 48: Percent distribution of multiple-offender victimizations, by type of crime, race of victims and perceived race of offenders
cv0849.csv   Table 49: Percent distribution of multiple-offender victimizations, by type of crime and detailed victim-offender relationship
           


                THE CRIME EVENT
cv0859.csv   Table 59: Percent distribution of incidents, by type of crime and time of occurrence
cv0860.csv   Table 60: Percent distribution of incidents, by type of crime, type of offender and time of occurrence
cv0861.csv   Table 61: Percent distribution of incidents, by type of crime and place of occurrence
cv0862.csv   Table 62: Percent distribution of incidents, by type of crime, type of offender and place of occurrence
cv0863.csv   Table 63: Percent distribution of incidents, by victim-offender relationship, type of crime and place of occurrence
cv0864.csv   Table 64: Percent distribution of incidents, by victim's activity at time of incident and type of crime
cv0865.csv   Table 65: Percent distribution of incidents, by distance from home and type of crime
cv0866.csv   Table 66: Percent of incidents, by victim-offender relationship, type of crime and weapons use
cv0867.csv   Table 67: Percent distribution of violent crime victimizations by who was first to use or threaten to use physical force
cv0868.csv   Table 68: Percent of victimizations in which victims took self-protective measures, by type of crime and victim-offender relationship
cv0869.csv   Table 69: Percent of victimizations in which victims took self-protective measures, by characteristics of victims and type of crime
cv0870.csv   Table 70: Percent distribution of self-protective measures employed by victims, by type of measure and type of crime
cv0871.csv   Table 71: Percent distribution of self-protective measures employed by victims, by selected characteristics of victims
cv0872.csv   Table 72: Percent victimizations in which self-protective measures employed, by person taking the measure, outcome of action and type of crime
cv0873.csv   Table 73: Percent distribution of victimizations in which self-protective measures taken by the victim were helpful
cv0874.csv   Table 74: Percent distribution of victimizations in which self-protective measures taken by the victim were harmful
cv0875.csv   Table 75: Percent of victimizations in which victims sustained physical injury, by selected characteristics of victim and type of crime 
cv0876.csv   Table 76: Percent distribution of victims receiving medical care, by type of crime and where care was received
cv0877.csv   Table 77: Percent of victimizations in which victims incurred medical expenses, by selected characteristics of victims and type of crime
cv0878.csv   Table 78: Percent of victimizations in which injured victims had health insurance coverage or were eligible for public medical services, by selected characteristics of victims
cv0879.csv   Table 79: Percent of victimizations in which victims received hospital care, by selected characteristics of victims and type of crime
cv0880.csv   Table 80: Percent distribution of victimizations in which injured victims received hospital care, by selected characteristics of victims, type of crime and type of  hospital care                  
cv0881.csv   Table 81: Percent of victimizations resulting in economic loss, by type of crime and type of loss
cv0882.csv   Table 82: Total economic loss to victims of crime
cv0883.csv   Table 83: Percent distribution of victimizations resulting in economic loss, by type of crime and value of loss
cv0884.csv   Table 84: Percent distribution of victimizations resulting in theft loss, by type of crime and type of property stole
cv0885.csv   Table 85: Percent distribution of victimizations resulting in theft loss, by race of victims, type of crime and value of loss
cv0886.csv   Table 86: Percent distribution of victimizations resulting in theft loss, by race of victims, type of crime and proportion of loss recovered
cv0887.csv   Table 87: Percent of victimizations resulting in loss of time from work, by type of crime
cv0888.csv   Table 88: Percent of victimizations resulting in loss of time from work, by type of crime and race of victims
cv0889.csv   Table 89: Percent distribution of victimizations resulting in loss of time from work, by type of crime and number of days lost
cv0890.csv   Table 90: Percent distribution of victimizations resulting in loss of time from work, by race of victims, type of crime, and number of days lost


 
             VICTIMS AND THE CRIMINAL JUSTICE SYSTEM
cv0891.csv   Table 91: Percent distribution of victimizations, by type of crime and whether or not reported to the police
cv0891b.csv Table 91b: Percent of victimizations reported to the police, by type of crime and sex and race or ethnicity of victims
cv0892.csv   Table 92: Percent of victimizations reported to the police, by selected characteristics of victims and type of crime
cv0893.csv   Table 93: Percent of victimizations reported to the police, by type of crime, victim-offender relationship and sex of victims
cv0893a.csv Table 93a: Number and percent distribution of victimizations reported to the police, by type of crime, and sex of head of household
cv0894.csv   Table 94: Percent of victimizations reported to the police, by type of crime, victim-offender relationship and race of victims
cv0895.csv   Table 95: Percent of victimizations reported to the police, by type of crime, victim-offender relationship and ethnicity of victims
cv0896.csv   Table 96: Percent of victimizations reported to the police, by type of crime and age of victims
cv0897.csv   Table 97: Percent of victimizations reported to the police, by type of crime, form of tenure, and race and ethnicity of head of household
cv0898.csv   Table 98: Percent of victimizations reported to the police, by type of crime and form of tenure
cv0899.csv   Table 99: Percent of victimizations reported to the police, by type of crime and annual family income
cv08100.csv Table 100: Percent of victimizations reported to the police, by value of loss and type of crime
cv08101.csv Table 101: Percent of reasons for reporting victimizations to the police, by type of crime
cv08102.csv Table 102: Percent of reasons for not reporting victimizations to the police, by type of crime
cv08103.csv Table 103: Percent of reasons for not reporting victimizations to the police, by race of victims and type of crime
cv08107.csv Table 107: Percent of reasons for not reporting victimizations to the police, by victim-offender relationship and type of crime
cv08105.csv Table 105: Percent of reasons for not reporting victimizations to the police, by race of head of household and type of crime
cv08106.csv Table 106: Percent distribution of police response to a reported incident, by type of crime
cv081.csv Table 1: Percent distribution of incidents where police came to the victim, by police response time and type of crime
cv08108.csv Table 108: Percent distribution of incidents, by police activity during initial contact with victim and type of crime
cv08109.csv Table 109: Percent distribution of the kind of agency providing assistance by type of crime
 
             SERIES VICTIMIZATIONS
cv08110.csv Table 110: Number and percent distribution of series victimizations and of victimizations not in series, by type of crime
 
 
 
 
 
 
 
 





