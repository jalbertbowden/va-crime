Indicators of School Crime and Safety:  2012  NCJ  241446			
			
This Zip archive contains Figures in individual .csv spreadsheets 			
from Indicators of School Crime and Safety:  201 NCJ 241446.			
The full report, including text and graphics in .pdf format are available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4677
			
This report is one in a series.  More recent editions may be available.  			
To view a list of all in the series go to http://www.bjs.gov/index.cfm?ty=pbse&sid=8			
			
			
Tables			
iscs12t01_1.csv			Table 1.1. Number of school-associated violent deaths, homicides, and suicides of youth ages 5�18, by location and year: School years 1992�93 to 2010�11
iscs12t01_2.csv			Table 1.2. Number of school-associated violent deaths of students, staff, and nonstudents, by type: School years 1992�93 to 2010�11
iscs12t02_1.csv			Table 2.1. Number of nonfatal victimizations against students ages 12�18 and rate of victimizations per 1,000 students, by type of victimization, location, and year: 1992�2011
iscs12t02_2.csv			Table 2.2. Number of nonfatal victimizations against students ages 12�18 and rate of victimizations per 1,000 students at school, by type of victimization and selected student characteristics: 2011
iscs12t02_3.csv			Table 2.3. Number of nonfatal victimizations against students ages 12�18 and rate of victimizations per 1,000 students away from school, by type of victimization and selected student characteristics: 2011
iscs12t03_1.csv			Table 3.1. Percentage of students ages 12�18 who reported criminal victimization at school during the previous 6 months, by type of victimization and selected student or school characteristics: Various years, 1995�2011
iscs12t04_1.csv			Table 4.1. Percentage of students in grades 9�12 who reported being threatened or injured with a weapon on school property at least one time during the previous 12 months, by selected student or school characteristics: Various years, 1993�2011
iscs12t04_2.csv			Table 4.2. Percentage of students in grades 9�12 who reported being threatened or injured with a weapon on school property during the previous 12 months, by number of times and selected student characteristics: 2011
iscs12t04_3.csv			Table 4.3. Percentage of public school students in grades 9�12 who reported being threatened or injured with a weapon on school property at least one time during the previous 12 months, by state and jurisdiction: Various years, 2003�2011
iscs12t05_1.csv			Table 5.1. Percentage and number of public and private school teachers who reported that they were threatened with injury by a student from school during the previous 12 months, by locale and selected teacher or school characteristics: Various school years, 1993�94 through 2007�08
iscs12t05_2.csv			Table 5.2. Percentage and number of public and private school teachers who reported that they were physically attacked by a student from school during the previous 12 months, by locale and selected teacher or school characteristics:  Various school years, 1993�94 through 2007�08
iscs12t05_3.csv			Table 5.3. Percentage and number of public school teachers who reported that they were threatened with injury by a student from school during the previous 12 months, by state: Various school years, 1993�94 through 2007�08  
iscs12t05_4.csv			Table 5.4. Percentage and number of public school teachers who reported that they were physically attacked by a student from school during the previous 12 months, by state: Various school years, 1993�94 through 2007�08
iscs12t06_1.csv			Table 6.1. Percentage distribution of public schools recording and reporting incidents of crime at school, number of incidents, and the rate of crimes per 1,000 students, by type of crime: Various school years, 1999�2000 through 2009�10
iscs12t06_2.csv			Table 6.2. Percentage of public schools recording incidents of crime at school, number of incidents, and the rate of crimes per 1,000 students, by type of crime and selected school characteristics: School year 2009�10
iscs12t06_3.csv			Table 6.3. Percentage of public schools reporting incidents of crime at school to the police, number of incidents, and the rate of crimes per 1,000 students, by type of crime and selected school characteristics: School year 2009�10
iscs12t06_4.csv			Table 6.4. Percentage of public schools recording and reporting to the police violent incidents of crime at school, by the number of incidents and selected school characteristics: School year 2009�10
iscs12t06_5.csv			Table 6.5. Percentage of public schools recording and reporting to the police serious violent incidents of crime at school, by the number of incidents and selected school characteristics: School year 2009�10
iscs12t07_1.csv			Table 7.1. Percentage of public schools reporting selected discipline problems that occurred at school, by frequency and school characteristics: School year 2009�10
iscs12t07_2.csv			Table 7.2. Percentage of public schools reporting selected discipline problems that occurred at school, by frequency: Various school years, 1999�2000 through 2009�10
iscs12t07_3.csv			Table 7.3. Percentage of public schools reporting selected types of cyber-bullying problems occurring at school or away from school daily or at least once a week, by selected school characteristics: School year 2009�10
iscs12t08_1.csv			Table 8.1. Percentage of students ages 12�18 who reported that gangs were present at school, during the school year, by urbanicity and selected student or school characteristics: Various years, 2001�2011
iscs12t09_1.csv			Table 9.1. Percentage of students in grades 9�12 who reported that illegal drugs were made available to them on school property during the previous 12 months, by selected student or school characteristics: Various years, 1993�2011
iscs12t09_2.csv			Table 9.2. Percentage of public school students in grades 9�12 who reported that illegal drugs were made available to them on school property during the previous 12 months, by state and jurisdiction: Various years, 2003�2011
iscs12t10_1.csv			Table 10.1. Percentage of students ages 12�18 who reported being the target of hate-related words and seeing hate-related graffiti at school during the school year, by selected student or school characteristics: Various years, 1999�2011		
iscs12t10_2.csv			Table 10.2. Percentage of students ages 12�18 who reported being the target of hate-related words at school during the school year, by type of hate-related word and selected student or school characteristics: 2011
iscs12t11_1.csv			Table 11.1. Percentage of students ages 12�18 who reported being bullied at school during the school year, by selected bullying problems and selected student or school characteristics: 2011
iscs12t11_2.csv			Table 11.2. Percentage of students ages 12�18 who reported being bullied at school during the school year and, among bullied students, percentage who reported being bullied in various locations, by selected student or school characteristics: 2011			
iscs12t11_3.csv			Table 11.3. Percentage of students ages 12�18 who reported being cyber-bullied anywhere during the school year, by selected cyber-bullying problems and selected student or school characteristics: 2011
iscs12t11_4.csv			Table 11.4. Percentage distribution of students ages 12�18 who reported being bullied at school and cyber-bullied anywhere during the school year, by the frequency of bullying, percentage of students who notified an adult, and selected student or school characteristics: 2011
iscs12t11_5.csv			Table 11.5. Percentage of students ages 12�18 who reported being bullied at school during the school year, by selected bullying problems and selected student or school characteristics: Various years, 2005�2011
iscs12t12_1.csv			Table 12.1. Percentage of public and private school teachers who agreed or strongly agreed that student misbehavior and student tardiness and class cutting interfered with their teaching, by selected teacher or school characteristics: Various school years, 1987�88 through 2007�08
iscs12t12_2.csv			Table 12.2. Percentage of public and private school teachers who agreed or strongly agreed that school rules are enforced by other teachers and by the principal, by selected teacher or school characteristics: Various school years, 1987�88 through 2007�08
iscs12t12_3.csv			Table 12.3. Percentage of public school teachers who agreed or strongly agreed that student misbehavior and student tardiness and class cutting interfered with their teaching and that school rules are enforced by other teachers and by the principal, by state: School year 2007�08
iscs12t13_1.csv			Table 13.1. Percentage of students in grades 9�12 who reported having been in a physical fight at least one time during the previous 12 months, by location and selected student characteristics: Various years, 1993�2011
iscs12t13_2.csv			Table 13.2. Percentage of students in grades 9�12 who reported having been in a physical fight during the previous 12 months, by location, number of times, and selected student characteristics: 2011
iscs12t13_3.csv			Table 13.3. Percentage of public school students in grades 9�12 who reported having been in a physical fight at least one time during the previous 12 months, by location and state and jurisdiction: Various years, 2003�2011  
iscs12t14_1.csv			Table 14.1. Percentage of students in grades 9�12 who reported carrying a weapon at least 1 day during the previous 30 days, by location and selected student characteristics: Various years, 1993�2011
iscs12t14_2.csv			Table 14.2. Percentage of students in grades 9�12 who reported carrying a weapon during the previous 30 days, by location, number of days, and selected student characteristics: 2011
iscs12t14_3.csv			Table 14.3. Percentage of public school students in grades 9�12 who reported carrying a weapon at least 1 day during the previous 30 days, by location and state and jurisdiction: Various years, 2003�2011
iscs12t14_4.csv			Table 14.4. Percentage of students ages 12�18 who reported having access to a loaded gun, without adult permission, at school or away from school during the school year, by selected student or school characteristics: 2007, 2009, and 2011
iscs12t15_1.csv			Table 15.1. Percentage of students in grades 9�12 who reported using alcohol at least 1 day during the previous 30 days, by location and selected student characteristics: Various years, 1993�2011
iscs12t15_2.csv			Table 15.2. Percentage of students in grades 9�12 who reported using alcohol during the previous 30 days, by location, number of days, and selected student characteristics: 2011
iscs12t15_3.csv			Table 15.3. Percentage of public school students in grades 9�12 who reported using alcohol at least 1 day during the previous 30 days, by location and state and jurisdiction: Various years, 2003�2011
iscs12t16_1.csv			Table 16.1. Percentage of students in grades 9�12 who reported using marijuana at least one time during the previous 30 days, by location and selected student characteristics: Various years, 1993�2011
iscs12t16_2.csv			Table 16.2. Percentage of students in grades 9�12 who reported using marijuana during the previous 30 days, by location, number of times, and selected student characteristics: 2011
iscs12t16_3.csv			Table 16.3. Percentage of public school students in grades 9�12 who reported using marijuana at least one time during the previous 30 days, by location and state and jurisdiction: Various years 2003�2011
iscs12t17_1.csv			Table 17.1. Percentage of students ages 12�18 who reported being afraid of attack or harm, by location and selected student or school characteristics: Various years, 1995�2011
iscs12t18_1.csv			Table 18.1. Percentage of students ages 12�18 who reported avoiding school activities or one or more places in school because of fear of attack or harm: Various years, 1995�2011
iscs12t18_2.csv			Table 18.2. Percentage of students ages 12�18 who reported avoiding one or more places in school because of fear of attack or harm, by selected student or school characteristics: Various years, 1995�2011
iscs12t19_1.csv			Table 19.1. Percentage of public schools that took a serious disciplinary action, by school level and type of offense: School year 2009�10
iscs12t19_2.csv			Table 19.2. Number and percentage of public schools that took a serious disciplinary action, number of serious actions taken, and percentage distribution of serious actions, by type of action and type of offense: School year 2009�10
iscs12t19_3.csv			Table 19.3. Percentage of public schools that took a serious disciplinary action and number of serious actions taken, by type of offense: Various school years, 1999�2000 through 2009�10
iscs12t20_1.csv			Table 20.1. Percentage of public schools that used safety and security measures: Various school years, 1999�2000 through 2009�10
iscs12t20_2.csv			Table 20.2. Percentage of public schools that used selected safety and security measures, by school characteristics: School year 2009�10
iscs12t20_3.csv			Table 20.3. Percentage of schools with one or more full-time or part-time security staff present at least once a week, and percentage of schools with security staff routinely carrying a firearm, by selected school characteristics: School years 2005�06, 2007�08, and 2009�10
iscs12t21_1.csv			Table 21.1. Percentage of students ages 12�18 who reported selected security measures at school: Various years, 1999�2011
			
			
Figures			
iscs12f01_1.csv			Figure 1.1. Number of student, staff, and nonstudent school-associated violent deaths, and number of homicides and suicides of youth ages 5�18 at school: School years 1992�93 to 2010�11
iscs12f01_2.csv			Figure 1.2. Number of school-associated homicides and suicides of youth ages 5�18, by location:2009�10 and 2010�11
iscs12f02_1.csv			Figure 2.1. Rate of nonfatal victimizations against students ages 12�18 per 1,000 students, by type of victimization and location: 1992�2011
iscs12f02_2.csv			Figure 2.2. Rate of nonfatal victimizations against students ages 12�18 at and away from school per 1,000 students, by type of victimization and age: 2011
iscs12f03_1.csv			Figure 3.1. Percentage of students ages 12�18 who reported criminal victimization at school during the previous 6 months, by type of victimization: Various years, 1995�2011
iscs12f03_2.csv			Figure 3.2. Percentage of students ages 12�18 who reported criminal victimization at school during the previous 6 months, by type of victimization and sex: 2011
iscs12f04_1.csv			Figure 4.1. Percentage of students in grades 9�12 who reported being threatened or injured with a weapon on school property at least one time during the previous 12 months, by sex: Various years, 1993�2011
iscs12f04_2.csv			Figure 4.2. Percentage of students in grades 9�12 who reported being threatened or injured with a weapon on school property at least one time during the previous 12 months, by race/ethnicity:
iscs12f04_3.csv			Figure 4.3. Percentage of students in grades 9�12 who reported being threatened or injured with a weapon on school property at least one time during the previous 12 months, by number of times and grade: 2011
iscs12f05_1.csv			Figure 5.1. Percentage of public and private school teachers who reported that they were threatened with injury or that they were physically attacked by a student from school during the previous 12 months: Various school years, 1993�94 through 2007�08
iscs12f05_2.csv			Figure 5.2. Percentage of public and private school teachers who reported that they were threatened with injury or that they were physically attacked by a student from school during the previous 12 months, by locale and instructional level: School year 2007�08
iscs12f06_1.csv			Figure 6.1. Percentage of public schools recording and reporting to police incidents of crime at school, and the rate of crimes per 1,000 students, by type of crime: School year 2009�10
iscs12f06_2.csv			Figure 6.2. Percentage of public schools recording and reporting to police incidents of crime at school, by type of incident and school level: School year 2009�10
iscs12f06_3.csv			Figure 6.3. Percentage of public schools recording and reporting to police violent and serious violent incidents of crime at school, by the number of incidents: School year 2009�10
iscs12f07_1.csv			Figure 7.1. Percentage of public schools reporting selected discipline problems that occurred at school, by locale: School year 2009�10
iscs12f07_2.csv			Figure 7.2. Percentage of public schools reporting selected types of cyber-bullying problems occurring at school or away from school daily or at least once a week, by school level: School year
iscs12f08_1.csv			Figure 8.1. Percentage of students ages 12�18 who reported that gangs were present at school during the school year, by urbanicity: 2009 and 2011
iscs12f08_2.csv			Figure 8.2. Percentage of students ages 12�18 who reported that gangs were present at school during the school year, by race/ethnicity: 2009 and 2011
iscs12f09_1.csv			Figure 9.1. Percentage of students in grades 9�12 who reported that illegal drugs were made available to them on school property during the previous 12 months, by sex: Various years, 1993�2011
iscs12f09_2.csv			Figure 9.2. Percentage of students in grades 9�12 who reported that illegal drugs were made available to them on school property during the previous 12 months, by race/ethnicity: 2011
iscs12f10_1.csv			Figure 10.1. Percentage of students ages 12�18 who reported being the target of hate-related words and seeing hate-related graffiti at school during the school year, by selected student and school characteristics: 2011
iscs12f10_2.csv			Figure 10.2. Percentage of students ages 12�18 who reported being the target of hate-related words at school during the school year, by type of hate-related word and sex: 2011
iscs12f11_1.csv			Figure 11.1. Percentage of students ages 12�18 who reported being bullied at school during the school year, by selected bullying problems and selected student or school characteristics: 2011
iscs12f11_2.csv			Figure 11.2. Percentage of students ages 12�18 who reported being bullied at school during the school year and, among bullied students, percentage who reported being bullied in various locations, by selected student or school characteristics: 2011
iscs12f11_3.csv			Figure 11.3. Percentage of students ages 12�18 who reported being cyber-bullied anywhere during the school year, by selected cyber-bullying problems and selected student or school characteristics: 2011
iscs12f11_4.csv			Figure 11.4. Percentage distribution of students ages 12-18 who reported being at school and cyber-bullied anywhere during the school year, by frequncy of bullying, percentage of students who notified an adult, and selected student or school characeteristics: 2011
iscs12f11_5.csv			Figure 11.5. Percentage of students ages 12�18 who reported being bullied at school during the school year, by selected school characteristics: Various years, 2005�2011
iscs12f12_1.csv			Figure 12.1. Percentage of public and private school teachers who agreed or strongly agreed that student misbehavior, student tardiness, and class cutting interfered with their teaching, by locale: School year 2007�08
iscs12f12_2.csv			Figure 12.2. Percentage of public and private school teachers who agreed or strongly agreed that school rules are enforced by other teachers and by the principal, by school level: School year 2007�08
iscs12f13_1.csv			Figure 13.1. Percentage of students in grades 9�12 who reported having been in a physical fight at least one time during the previous 12 months, by location and grade: various years, 1993-2011
iscs12f14_1.csv			Figure 14.1. Percentage of students in grades 9�12 who reported carrying a weapon at least one day during the previous 30 days, by location and sex: Various years, 1993�2011
iscs12f14_2.csv			Figure 14.2. Percentage of students in grades 9�12 who reported carrying a weapon at least one day during the previous 30 days, by race/ethnicity and location: 2011
iscs12f15_1.csv			Figure 15.1. Percentage of students in grades 9�12 who reported using alcohol at least one day during the previous 30 days, by location and sex: Various years, 1993�2011
iscs12f15_2.csv			Figure 15.2. Percentage of students in grades 9�12 who reported using alcohol at least one day during the previous 30 days, by location, number of days, and sex: 2011
iscs12f15_3.csv			Figure 15.3. Percentage of students in grades 9�12 who reported using alcohol at least one day during the previous 30 days, by grade and location: 2011
iscs12f15_4.csv			Figure 15.4. Percentage of students in grades 9�12 who reported using alcohol at least one day during the previous 30 days, by race/ethnicity and location: 2011
iscs12f16_1.csv			Figure 16.1. Percentage of students in grades 9�12 who reported using marijuana at least one time during the previous 30 days, by location and sex: Various years, 1993�2011
iscs12f16_2.csv			Figure 16.2. Percentage of students in grades 9�12 who reported using marijuana during the previous 30 days, by location, number of times, and sex: 2011
iscs12f16_3.csv			Figure 16.3. Percentage of students in grades 9�12 who reported using marijuana at least one time during the previous 30 days, by race/ethnicity and location: 2011
iscs12f16_4.csv			Figure 16.4. Percentage of students in grades 9�12 who reported using marijuana at least one time during the previous 30 days, by grade and location: 2011
iscs12f17_1.csv			Figure 17.1. Percentage of students ages 12�18 who reported being afraid of attack or harm during the school year, by location and urbanicity: 2011
iscs12f18_1.csv			Figure 18.1. Percentage of students ages 12�18 who reported avoiding school activities or one or more places in school because of fear of attack or harm during the school year: 2011
iscs12f19_1.csv			Figure 19.1. Percentage of public schools that took a serious disciplinary action, by type of offense and school level: School year 2009�10
iscs12f19_2.csv			Figure 19.2. Percentage distribution of serious disciplinary actions taken by public schools, by type of offense and type of disciplinary action: School year 2009�10
iscs12f19_3.csv			Figure 19.3. Percentage of public schools that took a serious disciplinary action, by type of offense: Various school years, 1999�2000 through 2009�10
iscs12f20_1.csv			Figure 20.1. Percentage of public schools that used selected safety and security measures: School year 2009�10
iscs12f20_2.csv			Figure 20.2. Percentage of public schools that used selected safety and security measures: Various school years, 1999�2000 through 2009�10
iscs12f21_1.csv			Figure 21.1. Percentage of students ages 12�18 who reported selected security measures at school: Various years, 1999�2011


SE Tables
iscs12ts02_1.csv		Table S2.1. Standard errors for the number of nonfatal victimizations against students ages 12�18 and rate of victimizations per 1,000 students, by type of victimization, location, and year: 1992�2011
iscs12ts02_2.csv		Table S2.2. Standard errors for the number of nonfatal victimizations against students ages 12�18 and rate of victimizations per 1,000 students at school, by type of victimization and selected student characteristics: 2011
iscs12ts02_3.csv		Table S2.3. Standard errors for the number of nonfatal victimizations against students ages 12�18 and rate of victimizations per 1,000 students away from school, by type of victimization and selected student characteristics: 2011
iscs12ts03_1.csv		Table S3.1. Standard errors for the percentage of students ages 12�18 who reported criminal victimization at school during the previous 6 months, by type of victimization and selected student or school characteristics: Various years, 1995�2011
iscs12ts04_1.csv		Table S4.1. Standard errors for the percentage of students in grades 9�12 who reported being threatened or injured with a weapon on school property at least one time during the previous 12 months, by selected student or school characteristics: Various years, 1993�2011
iscs12ts04_2.csv		Table S4.2. Standard errors for the percentage of students in grades 9�12 who reported being threatened or injured with a weapon on school property during the previous 12 months, by number of times and selected student characteristics: 2011
iscs12ts04_3.csv		Table S4.3. Standard errors for the percentage of public school students in grades 9�12 who reported being threatened or injured with a weapon on school property at least one time during the previous 12 months, by state and jurisdiction: Various years, 2003�2011
iscs12ts05_1.csv		Table S5.1. Standard errors for the percentage and number of public and private school teachers who reported that they were threatened with injury by a student from school during the previous 12 months, by urbanicity and selected teacher or school characteristics: Various school years, 1993�94 through 2007�08
iscs12ts05_2.csv		Table S5.2. Standard errors for the percentage and number of public and private school teachers who reported that they were physically attacked by a student from school during the previous 12 months, by urbanicity and selected teacher or school characteristics: Various school years, 1993�94 through 2007�08
iscs12ts05_3.csv		Table S5.3. Standard errors for the percentage and number of public school teachers who reported that they were threatened with injury by a student from school during the previous 12 months, by state: Various school years, 1993�94 through 2007�08
iscs12ts05_4.csv		Table S5.4. Standard errors for the percentage and number of public school teachers who reported that they were physically attacked by a student from school during the previous 12 months, by state: Various school years, 1993�94 through 2007�08
iscs12ts06_1.csv		Table S6.1. Standard errors for the percentage distribution of public schools recording and reporting incidents of crime at school, number of incidents, and the rate of crimes per 1,000 students, by type of crime: Various school years, 1999�2000 through 2009�10
iscs12ts06_2.csv		Table S6.2. Standard errors for the percentage of public schools recording incidents of crime at school, number of incidents, and the rate of crimes per 1,000 students, by type of crime and selected school characteristics: School year 2009�10
iscs12ts06_3.csv		Table S6.3. Standard errors for the percentage of public schools reporting incidents of crime at school to the police, number of incidents, and the rate of crimes per 1,000 students, by type of crime and selected school characteristics: School year 2009�10
iscs12ts06_4.csv		Table S6.4. Standard errors for the percentage of public schools recording and reporting to the police violent incidents of crime at school, by the number of incidents and selected school characteristics: School year 2009�10
iscs12ts06_5.csv		Table S6.5. Standard errors for the percentage of public schools recording and reporting to the police serious violent incidents of crime at school, by the number of incidents and selected school characteristics:School year 2009�10
iscs12ts07_1.csv		Table S7.1. Standard errors for the percentage of public schools reporting selected discipline problems that occurred at school, by frequency and school characteristics: School year 2009�10
iscs12ts08_1.csv		Table S8.1. Standard errors for the percentage of students ages 12�18 who reported that gangs were present at school, during the school year, by urbanicity and selected student or school characteristics: Various years, 2001�2011
iscs12ts09_1.csv		Table S9.1. Standard errors for the percentage of students in grades 9�12 who reported that illegal drugs were made available to them on school property during the previous 12 months, by selected student or school characteristics: Various years, 1993�2011
iscs12ts09_2.csv		Table S9.2. Standard errors for the percentage of public school students in grades 9�12 who reported that illegal drugs were made available to them on school property during the previous 12 months, by state and jurisdiction: Various years, 2003�2011
iscs12ts10_1.csv		Table S10.1. Standard errors for the percentage of students ages 12�18 who reported being the target of hate-related words and seeing hate-related graffiti at school, by selected student or school characteristics: Various years, 1999�2011
iscs12ts10_2.csv		Table S10.2. Standard errors for the percentage of students ages 12�18 who reported being the target of hate-related words at school during the school year, by type of hate-related word and selected student or school characteristics: 2011
iscs12ts11_1.csv		Table S11.1. Standard errors for the percentage of students ages 12�18 who reported being bullied at school during the school year, by selected bullying problems and selected student or school characteristics: 2011
iscs12ts11_2.csv		Table S11.2. Standard errors for the percentage of students ages 12�18 who reported being bullied at school during the school year and, among bullied students, percentage who reported being bullied in various locations, by selected student or school characteristics: 2011
iscs12ts11_3.csv		Table S11.3. Standard errors for the percentage of students ages 12�18 who reported being cyber-bullied anywhere during the school year, by selected cyber-bullying problems and selected student or school characteristics: 2011
iscs12ts11_4.csv		Table S11.4. Standard errors for the percentage distribution of students ages 12�18 who reported being bullied at school and cyber-bullied anywhere during the school year, by the frequency of bullying, percentage of students who notified an adult, and selected student or school characteristics: 2011
iscs12ts11_5.csv		Table S11.5. Standard errors for the percentage of students ages 12�18 who reported being bullied at school during the school year, by selected bullying problems and selected student or school characteristics: Various years, 2005�2011
iscs12ts12_1.csv		Table S12.1. Standard errors for the percentage of public and private school teachers who agreed or strongly agreed that student misbehavior and student tardiness and class cutting interfered with their teaching, by selected teacher or school characteristics: Various school years, 1987�88 through 2007�08
iscs12ts12_2.csv		Table S12.2. Standard errors for the percentage of public and private school teachers who agreed or strongly agreed that school rules are enforced by other teachers and by the principal, by selected teacher or school characteristics: Various school years, 1987�88 through 2007�08
iscs12ts12_3.csv		Table S12.3. Standard errors for the percentage of public school teachers who agreed or strongly agreed that student misbehavior and student tardiness and class cutting interfered with their teaching and that school rules are enforced by other teachers and by the principal, by state: School year 2007�08
iscs12ts13_1.csv		Table S13.1. Standard errors for the percentage of students in grades 9�12 who reported having been in a physical fight at least one time during the previous 12 months, by location and selected student characteristics: Various years, 1993�2011 
iscs12ts13_2.csv		Table S13.2. Standard errors for the percentage of students in grades 9�12 who reported having been in a physical fight during the previous 12 months, by location, number of times, and selected student characteristics: 2011
iscs12ts13_3.csv		Table S13.3. Standard errors for the percentage of public school students in grades 9�12 who reported having been in a physical fight at least one time during the previous 12 months, by location and state and jurisdiction: Various years, 2003�2011
iscs12ts14_1.csv		Table S14.1. Standard errors for the percentage of students in grades 9�12 who reported carrying a weapon at least 1 day during the previous 30 days, by location and selected student characteristics: Various years, 1993�2011
iscs12ts14_2.csv		Table S14.2. Standard errors for the percentage of students in grades 9�12 who reported carrying a weapon during the previous 30 days, by location, number of days, and selected student characteristics: 2011
iscs12ts14_3.csv		Table S14.3. Standard errors for the percentage of public school students in grades 9�12 who reported carrying a weapon at least 1 day during the previous 30 days, by location and state and jurisdiction: Various years, 2003�2011
iscs12ts14_4.csv		Table S14.4. Standard errors for the percentage of students ages 12�18 who reported having access to a loaded gun, without adult permission, at school or away from school during the school year, by selected student or school characteristics: 2007, 2009, and 2011
iscs12ts15_1.csv		Table S15.1. Standard errors for the percentage of students in grades 9�12 who reported using alcohol at least 1 day during the previous 30 days, by location and selected student characteristics: Various years, 1993�2011
iscs12ts15_2.csv		Table S15.2. Standard errors for the percentage of students in grades 9�12 who reported using alcohol during the previous 30 days, by location, number of days, and selected student characteristics: 2011
iscs12ts15_3.csv		Table S15.3. Standard errors for the percentage of public school students in grades 9�12 who reported using alcohol at least 1 day during the previous 30 days, by location and state and jurisdiction: Various years, 2003�2011 
iscs12ts16_1.csv		Table S16.1. Standard errors for the percentage of students in grades 9�12 who reported using marijuana at least one time during the previous 30 days, by location and selected student characteristics: Various years, 1993�2011 	
iscs12ts16_2.csv		Table S16.2. Standard errors for the percentage of students in grades 9�12 who reported using marijuana during the previous 30 days, by location, number of times, and selected student characteristics: 2011
iscs12ts16_3.csv		Table S16.3. Standard errors for the percentage of public school students in grades 9�12 who reported using marijuana at least one time during the previous 30 days, by location and state and jurisdiction: Various years, 2003�2011
iscs12ts17_1.csv		Table S17.1. Standard errors for the percentage of students ages 12�18 who reported being afraid of attack or harm, by location and selected student or school characteristics: Various years, 1995�2011
iscs12ts18_1.csv		Table S18.1. Standard errors for the percentage of students ages 12�18 who reported avoiding school activities or one or more places in school because of fear of attack or harm: Various years, 1995�2011
iscs12ts18_2.csv		Table S18.2. Standard errors for the percentage of students ages 12�18 who reported avoiding one or more places in school because of fear of attack or harm, by selected student or school characteristics: Various years, 1995-2011
iscs12ts19_1.csv		Table S19.1. Standard errors for the percentage of public schools that took a serious disciplinary action, by school level and type of offense: School year 2009�10
iscs12ts20_1.csv		Table S20.1. Standard errors for the percentage of public schools that used safety and security measures: Various school years, 1999�2000 through 2009�10
iscs12ts21_1.csv		Table S21.1. Standard errors for the percentage of students ages 12�18 who reported selected security measures at school: Various years, 1999�2011



















