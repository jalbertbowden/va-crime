Nonfatal Domestic Violence, 2003�2012				NCJ 244697
				
This zip archive contains tables in individual  .csv spreadsheets				
from Nonfatal Domestic Violence, 2003�2012, NCJ 244697.  The full report including text				
and graphics in pdf format is available from: http://www.bjs.gov/index.cfm?ty=pbdetail&iid=4984				
				
Filename				
				
Figures				
ndv0312f01.csv		Figure 1. Violent victimization, by victim�offender relationship, 2003�2012		
ndv0312f02.csv		Figure 2. Rate of domestic violence, by victim�offender relationship, 1993�2012		
ndv0312f03.csv		Figure 3. Rate of serious domestic violence, by victim�offender relationship, 1993�2012		
ndv0312f04.csv		Figure 4. Rate of simple assault domestic violence, by victim�offender relationship, 1993�2012		
ndv0312f05.csv		Figure 5. Victim�offender relationships in domestic violence victimizations, by victim�s sex, 2003�2012		
ndv0312f06.csv		Figure 6. Composition of victim�offender relationships in domestic violence victimizations, by victim�s sex, 2003�2012		
				
Tables				
ndv0312t01.csv		Table 1. Violent victimization, by type of crime and victim�offender relationship, 2003�2012		
ndv0312t02.csv		Table 2. Rate of violent victimization, by victim�offender relationship, 2003�2012		
ndv0312t03.csv		Table 3. Percent of violent victimization, by victim�offender relationship and victim�s sex, 2003�2012		
ndv0312t04.csv		Table 4. Percent of violent victimization, by victim�offender relationship and victim�s age, 2003�2012		
ndv0312t05.csv		Table 5. Average annual number and percent of violent victimizations, by victim�offender relationship, 2003�2012		
ndv0312t06.csv		Table 6. Violent victimization resulting in injury and medical treatment, by victim�offender relationship, 2003�2012		
ndv0312t07.csv		Table 7. Violent victimization involving a weapon, by victim�offender relationship, 2003�2012		
ndv0312t08.csv		Table 8. Violent victimization reported to police, by victim�offender relationship, 2003�2012		
ndv0312t09.csv		Table 9. Violent crime victims who received assistance from a victim service agency, by victim�offender relationship, 2003�2012		
ndv0312t10.csv		Table 10. Location of violent victimization, by victim�offender relationship, 2003�2012		
ndv0312t11.csv		Table 11. Rate of violent victimization, by victim characteristics and victim�offender relationship, 2003�2012		
ndv0312t12.csv		Table 12. Rate of violent victimization, by household location and victim�offender relationship, 2003�2012		
				
Appendix tables				
ndv0312at01.csv		Appendix table 1. Estimates and standard errors for figure 1: Violent victimization, by victim�offender relationship, 2003�2012		
ndv0312at02.csv		Appendix table 2. Standard errors for table 1: Violent victimization, by type of crime and victim�offender relationship, 2003�2012		
ndv0312at03.csv		Appendix table 3. Estimates and standard errors for figure 2: Rate of domestic violence, by victim�offender relationship, 1993�2012		
ndv0312at04.csv		Appendix table 4. Estimates and standard errors for figure 3: Rate of serious domestic violence, by victim�offender relationship, 1993�2012		
ndv0312at05.csv		Appendix table 5. Estimates and standard errors for figure 4: Rate of simple assault domestic violence, by victim�offender relationship, 1993�2012		
ndv0312at06.csv		Appendix table 6. Standard errors for table 2: Rate of violent victimization, by  victim�offender relationship, 2003�2012		
ndv0312at07.csv		Appendix table 7. Standard errors for table 3: Percent of violent victimization, victim�offender relationship and victim�s sex, 2003�2012		
ndv0312at08.csv		Appendix table 8. Standard errors for table 4: Percent of violent victimization, by victim�offender relationship and victim�s age, 2003�2012		
ndv0312at09.csv		Appendix table 9. Estimates and standard errors for figure 5: Victim�offender relationships in domestic violence victimizations, by victim�s sex, 2003�2012		
ndv0312at10.csv		Appendix table 10. Estimates and standard errors for figure 6: Composition of victim�offender relationships in domestic violence victimizations, by victim�s sex, 2003�2012		
ndv0312at11.csv		Appendix table 11. Standard errors for table 5: Average annual number and percent of violent victimizations, by victim�offender relationship, 2003�2012		
ndv0312at12.csv		Appendix table 12. Standard errors for table 6: Violent victimization resulting in injury and medical treatment, by victim�offender relationship, 2003�2012		
ndv0312at13.csv		Appendix table 13. Standard errors for table 7: Violent victimization involving a weapon, by victim�offender relationship, 2003�2012		
ndv0312at14.csv		Appendix table 14. Standard errors for table 8: Violent victimization reported to police, by victim�offender relationship, 2003�2012		
ndv0312at15.csv		Appendix table 15. Standard errors for table 9: Violent crime victims who received assistance from a victim service agency, by victim�offender relationship, 2003�2012		
ndv0312at16.csv		Appendix table 16. Standard errors for table 10: Location of violent victimization, by victim�offender relationship, 2003�2012		
ndv0312at17.csv		Appendix table 17. Standard errors for table 11: Rate of violent victimization, by victim characteristics and victim�offender relationship, 2003�2012		
ndv0312at18.csv		Appendix table 18. Standard errors for table 12: Rate of violent victimization, by household location and victim�offender relationship, 2003�2012		
