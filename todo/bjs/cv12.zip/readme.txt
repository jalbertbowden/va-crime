Criminal Victimization, 2012      NCJ 243389			
			
This zip archive contains tables in individual  .csv spreadsheets			
from Criminal Victimization, 2012, NCJ 243389.  The full report including text			
and graphics in pdf format is available from: http://www.bjs.gov//index.cfm?ty=pbdetail&iid=4781			
			
This report is one in a series.  More recent editions			
may be available.  To view a list of all in the series go to			
http://www.bjs.gov/index.cfm?ty=pbse&sid=6			
			
			
Filename			Table title
cv12t01.csv			Table 1. Violent victimization, by type of violent crime, 2003, 2011, and 2012
cv12t02.csv			Table 2. Firearm violence, 2003, 2011, and 2012
cv12t03.csv			Table 3. Property victimization, by type of property crime, 2003, 2011, and 2012
cv12t04.csv			Table 4. Percent of victimization reported to police, by type of crime, 2003, 2011, and 2012
cv12t05.csv			Table 5. Violent victimization rate for crimes reported and not reported to police, by type of crime, 2003, 2011, and 2012
cv12t06.csv			Table 6. Violent crime victims who received assistance from a victim service agency, by type of crime, 2003, 2011, and 2012
cv12t07.csv			Table 7. Rate of violent victimization, by demographic characteristics of victims, 2003, 2011, and 2012
cv12t08.csv			Table 8. Rate of violent and property victimization, by household location, 2003, 2011, and 2012
cv11t09.csv			Table 9. Percent change in the number of crimes reported in UCR and NCVS, 2011?2012
			
Figures			
cv12f01.csv			Figure 1. Violent victimization reported and not reported to police, 1993?2012
cv12f02.csv			Figure 2. Homicide victimization, 1993?2011
cv12f03.csv			Figure 3. Rate of violent victimization, by type of crime, 1993?2012
cv12f04.csv			Figure 4. Percent of violent victimization, by type of crime, 1993?2012
			
Appendix tables			
cv12at01.csv			Appendix table 1. Estimates and standard errors for figure 1: Violent victimization reported and not reported to police, 1993?2012
cv12at02.csv			Appendix table 2. Standard errors for table 1: Violent victimization, by type of violent crime, 2003, 2011, and 2012
cv12at03.csv			Appendix table 3. Standard errors for table 2: Firearm violence, 2003, 2011, and 2012
cv12at04.csv			Appendix table 4. Estimates for figure 2: Homicide victimization, 1993?2011
cv12at05.csv			Appendix table 5. Standard errors for table 3: Property victimization, by type of property crime, 2003, 2011, and 2012
cv12at06.csv			Appendix table 6. Standard errors for table 4: Percent of victimization reported to police, by type of crime, 2003, 2011, and 2012
cv12at07.csv			Appendix table 7. Violent victimization rate for crimes reported and not reported to police, by type of crime, 2003, 2011, and 2012
cv12at08.csv			Appendix table 8. Estimates and standard errors for figure 3: Rate of violent victimization, by type of crime, 1993?2012
cv12at09.csv			Appendix table 9. Estimates and standard errors for figure 4: Percent of violent victimization, by type of crime, 1993?2012
cv12at10.csv			Appendix table 10. Standard errors for table 6: Violent crime victims who received assistance from a victim service agency, by type of crime, 2003, 2011, and 2012
cv12at11.csv			Appendix table 11. Standard errors for table 7: Rate of violent victimization, by demographic characteristics of victims, 2003, 2011, and 2012
cv12at12.csv			Appendix table 12. Standard errors for table 8: Rate of violent and property victimization, by household location, 2003, 2011, and 2012
